.. code:: ipython3

    # ---------------------------------------------------------------
    # QAOA Algorithm – Clean vs Malicious Dataset (Qiskit Simulation)
    # ---------------------------------------------------------------
    
    # This notebook implements the Quantum Approximate Optimization Algorithm (QAOA)
    # using Qiskit, simulating both clean and malicious quantum circuits to generate
    # a dataset for anomaly detection and Trojan circuit classification.
    
    # Objective:
    # - Generate 10 clean QAOA circuits for MaxCut (3-node graphs)
    # - Generate 10 malicious QAOA circuits with subtle tampering behaviors
    # - Simulate all circuits using IBM Qiskit Runtime and extract rich features
    
    # Dataset Composition:
    # - Clean circuits labeled as 0
    # - Malicious circuits labeled as 1
    # - Each entry includes gate metrics (depth, counts) and execution metrics (entropy, output variance)
    
    # Threat Model:
    # - Malicious QAOA variants simulate adversarial perturbations such as:
    #     • Gate injections (X, CX, CCX)
    #     • Altered mixer/phase separator layers
    #     • Modified graph edge encoding
    #     • Over-parametrized depth (to mimic decoherence)
    
    # Visualization & Analysis:
    # - All circuits saved as diagrams and histograms
    # - Dataset exported to CSV
    # - Class distribution and feature correlation heatmap plotted
    
    # Environment:
    # - Qiskit + IBM Runtime
    # - Matplotlib, Seaborn, Pandas, NumPy for visualization and data handling
    
    # This notebook supports secure quantum computing research by modeling
    # optimization circuit behaviors under clean and adversarial settings.
    
    # Author: Zeeshan Ajmal
    

.. code:: ipython3

    # --------------------------------------------------
    # Qiskit + Runtime + Visualization + Utilities Setup
    # --------------------------------------------------
    
    # Core Qiskit
    from qiskit import QuantumCircuit, transpile
    from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as norm_sampler
    
    # Visualization
    %matplotlib inline
    from qiskit.visualization import plot_histogram, plot_circuit_layout
    import matplotlib.pyplot as plt
    import seaborn as sns
    
    # Utility Libraries
    import numpy as np
    import pandas as pd
    from scipy.stats import entropy as shannon_entropy
    import os
    
    # Initialize IBM Qiskit Runtime
    service = QiskitRuntimeService(
        channel='ibm_quantum',
        instance='ibm-q/open/main',
        token='ff1dde434d0dcec5608d0b0166f3df690e5b8258114b55d50805fe2c5c25d03a520f7551cd363d5295b421ab19908870fc00cdfb57a074f0a7eaa6c9ff2fa9e6'
    )
    
    # Select Backend
    backend = service.backend("ibm_brisbane")
    

.. code:: ipython3

    # --------------------------------------------------
    # Function: Generate Clean QAOA Circuit (MaxCut)
    # --------------------------------------------------
    
    from qiskit.circuit.library import RZZGate, RXGate
    from qiskit.quantum_info import Pauli
    
    
    def generate_qaoa_clean_variation(index):
        """
        Generate a clean QAOA circuit solving a 3-qubit MaxCut problem
        with depth p = 1. The graph edges are fixed across all clean circuits,
        but angles (γ, β) vary slightly with index.
        """
        n = 3  # number of qubits
        qc = QuantumCircuit(n)
    
        # Define graph edges for MaxCut (triangle: fully connected 3-node)
        edges = [(0, 1), (1, 2), (0, 2)]
    
        # Initial state: Apply Hadamard to all qubits
        qc.h(range(n))
    
        # Parameters (vary slightly per instance)
        gamma = (index + 1) * np.pi / 16
        beta = (index + 1) * np.pi / 8
    
        # Apply cost unitary (Z-Z phase separators)
        for (i, j) in edges:
            qc.cx(i, j)
            qc.rz(-2 * gamma, j)
            qc.cx(i, j)
    
        # Apply mixer unitary (X rotations)
        for i in range(n):
            qc.rx(2 * beta, i)
    
        # Final measurement
        qc.measure_all()
    
        return qc
    

.. code:: ipython3

    # --------------------------------------------------
    # Generate & Store Clean QAOA Circuit Variants
    # --------------------------------------------------
    
    # Dictionary to hold clean QAOA circuits
    qaoa_clean_circuits = {}
    
    # Generate 10 clean variations
    for i in range(10):
        circuit = generate_qaoa_clean_variation(i)
        qaoa_clean_circuits[f"qaoa_clean_{i}"] = circuit
    

.. code:: ipython3

    # --------------------------------------------------
    # Simulate, Visualize, and Store Clean QAOA Outputs
    # --------------------------------------------------
    
    # Create folders for visualizations
    os.makedirs("qaoa_clean_diagrams", exist_ok=True)
    os.makedirs("qaoa_clean_histograms", exist_ok=True)
    
    results_summary_qaoa_clean = []
    
    for i in range(10):
        circuit_name = f"qaoa_clean_{i}"
        circuit = qaoa_clean_circuits[circuit_name]
    
        # Transpile & run
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract measurement counts
        counts = result[0].data.meas.get_counts()
        success_state = max(counts, key=counts.get)
        percentage = counts[success_state] / sum(counts.values()) * 100
    
        # Save circuit diagram
        circuit.draw("mpl", filename=f"qaoa_clean_diagrams/{circuit_name}.png")
    
        # Save histogram
        fig = plot_histogram(counts, title=f"{circuit_name} | {percentage:.2f}% success")
        fig.savefig(f"qaoa_clean_histograms/{circuit_name}_histogram.png")
        plt.show()
    
        # Store result summary
        results_summary_qaoa_clean.append({
            "name": circuit_name,
            "success_state": success_state,
            "success_rate": percentage
        })
    
    # Display summary
    for res in results_summary_qaoa_clean:
        print(f"{res['name']} | State: {res['success_state']} | Success Rate: {res['success_rate']:.2f}%")
    



.. image:: output_4_0.png



.. image:: output_4_1.png



.. image:: output_4_2.png



.. image:: output_4_3.png



.. image:: output_4_4.png



.. image:: output_4_5.png



.. image:: output_4_6.png



.. image:: output_4_7.png



.. image:: output_4_8.png



.. image:: output_4_9.png



.. image:: output_4_10.png



.. image:: output_4_11.png



.. image:: output_4_12.png



.. image:: output_4_13.png



.. image:: output_4_14.png



.. image:: output_4_15.png



.. image:: output_4_16.png



.. image:: output_4_17.png



.. image:: output_4_18.png



.. image:: output_4_19.png


.. parsed-literal::

    qaoa_clean_0 | State: 011 | Success Rate: 19.36%
    qaoa_clean_1 | State: 000 | Success Rate: 28.44%
    qaoa_clean_2 | State: 111 | Success Rate: 35.64%
    qaoa_clean_3 | State: 100 | Success Rate: 15.45%
    qaoa_clean_4 | State: 111 | Success Rate: 34.25%
    qaoa_clean_5 | State: 000 | Success Rate: 26.68%
    qaoa_clean_6 | State: 100 | Success Rate: 23.17%
    qaoa_clean_7 | State: 011 | Success Rate: 13.38%
    qaoa_clean_8 | State: 011 | Success Rate: 21.53%
    qaoa_clean_9 | State: 111 | Success Rate: 27.83%
    

.. code:: ipython3

    # --------------------------------------------------
    # Feature Extraction for QAOA Circuits
    # --------------------------------------------------
    
    def extract_qaoa_features(circuit_name, circuit, result, label):
        # Structural features
        ops = circuit.count_ops()
        num_cx = ops.get('cx', 0)
        num_h = ops.get('h', 0)
        num_x = ops.get('x', 0)
        num_ccx = ops.get('ccx', 0)
        num_rx = ops.get('rx', 0)
        num_rz = ops.get('rz', 0)
        depth = circuit.depth()
        total_gates = sum(ops.values())
    
        # Measurement-based features
        counts = result[0].data.meas.get_counts()
        probs = np.array(list(counts.values()))
        probs = probs / probs.sum()
    
        success_state = max(counts, key=counts.get)
        success_rate = counts[success_state] / sum(counts.values()) * 100
        entropy = shannon_entropy(probs, base=2)
        unique_states = len(counts)
    
        return {
            "name": circuit_name,
            "depth": depth,
            "cx": num_cx,
            "h": num_h,
            "x": num_x,
            "rx": num_rx,
            "rz": num_rz,
            "ccx": num_ccx,
            "total_gates": total_gates,
            "success_rate": success_rate,
            "entropy": entropy,
            "unique_states": unique_states,
            "label": label
        }
    

.. code:: ipython3

    # --------------------------------------------------
    # Feature Extraction & Save: Clean QAOA Circuits
    # --------------------------------------------------
    
    qaoa_clean_dataset = []
    
    # Loop through QAOA clean circuits
    for i in range(10):
        name = f"qaoa_clean_{i}"
        circuit = qaoa_clean_circuits[name]
    
        # Transpile and run
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract and collect features
        features = extract_qaoa_features(name, circuit, result, label=0)
        qaoa_clean_dataset.append(features)
    
    # Convert to DataFrame
    df_qaoa_clean = pd.DataFrame(qaoa_clean_dataset)
    
    # Display and export
    print(df_qaoa_clean)
    df_qaoa_clean.to_csv("qaoa_clean_dataset.csv", index=False)
    


.. parsed-literal::

               name  depth  cx  h  x  rx  rz  ccx  total_gates  success_rate  \
    0  qaoa_clean_0     12   6  3  0   3   3    0           19     22.534180   
    1  qaoa_clean_1     12   6  3  0   3   3    0           19     30.786133   
    2  qaoa_clean_2     12   6  3  0   3   3    0           19     34.838867   
    3  qaoa_clean_3     12   6  3  0   3   3    0           19     16.870117   
    4  qaoa_clean_4     12   6  3  0   3   3    0           19     36.914062   
    5  qaoa_clean_5     12   6  3  0   3   3    0           19     32.861328   
    6  qaoa_clean_6     12   6  3  0   3   3    0           19     23.730469   
    7  qaoa_clean_7     12   6  3  0   3   3    0           19     13.623047   
    8  qaoa_clean_8     12   6  3  0   3   3    0           19     17.211914   
    9  qaoa_clean_9     12   6  3  0   3   3    0           19     30.981445   
    
        entropy  unique_states  label  
    0  2.756504              8      0  
    1  2.670489              8      0  
    2  2.363559              8      0  
    3  2.948300              8      0  
    4  2.238368              8      0  
    5  2.686598              8      0  
    6  2.759173              8      0  
    7  2.998479              8      0  
    8  2.850210              8      0  
    9  2.640481              8      0  
    

.. code:: ipython3

    # --------------------------------------------------
    # Malicious QAOA Circuit Generation (Trojan Simulation)
    # --------------------------------------------------
    
    # This section generates 10 tampered QAOA circuits to simulate Trojan attacks
    # or adversarial modifications targeting the variational optimization layer.
    
    # Attack Simulation Strategies:
    # 1. Parameter tampering: Alter β or γ rotation angles
    # 2. Gate Injection: Insert X, RX, CX, or CCX gates after cost or mixer layers
    # 3. Graph Mutation: Remove or duplicate edges in the MaxCut graph
    # 4. Redundant layers: Apply additional rotations to introduce decoherence
    # 5. Entanglement distortion: Swap entangled qubit pairs
    
    #  Objective:
    # - Create circuits that look structurally valid but deviate semantically
    # - All samples will be labeled `1` (malicious)
    # - Used for classification against clean QAOA baselines
    
    # This Trojan simulation is essential for testing the robustness of
    # quantum machine learning models against adversarial quantum inputs.
    

.. code:: ipython3

    # --------------------------------------------------
    # Function: Generate Malicious QAOA Circuit
    # --------------------------------------------------
    
    def generate_qaoa_malicious_variation(index):
        """
        Generate a tampered QAOA circuit variant.
        Trojan behaviors include faulty angles, extra gates, or structural tweaks.
        """
        n = 3
        qc = QuantumCircuit(n)
    
        # Base graph (fully connected)
        edges = [(0, 1), (1, 2), (0, 2)]
    
        # Start with Hadamards
        qc.h(range(n))
    
        # Slightly wrong angles
        gamma = (index + 1) * np.pi / 12   # Over-rotated
        beta = (index + 2) * np.pi / 6     # Over-rotated
    
        # Cost unitary with tampering
        for (i, j) in edges:
            qc.cx(i, j)
            qc.rz(-2 * gamma, j)
            qc.cx(i, j)
    
        # Trojan injections: Add extra gates after cost layer
        if index % 3 == 0:
            qc.x(0)
        elif index % 3 == 1:
            qc.ccx(0, 1, 2)
        else:
            qc.rx(np.pi / 4, 1)
    
        # Mixer unitary with noise
        for i in range(n):
            qc.rx(2 * beta, i)
    
        # Add noisy entanglement or mimic decoherence
        if index % 2 == 0:
            qc.cx(2, 0)
        else:
            qc.swap(0, 1)
    
        qc.measure_all()
        return qc
    

.. code:: ipython3

    # --------------------------------------------------
    # Generate & Store All Malicious QAOA Circuit Variants
    # --------------------------------------------------
    
    # Dictionary to hold malicious QAOA circuits
    qaoa_malicious_circuits = {}
    
    # Generate 10 malicious variations
    for i in range(10):
        circuit = generate_qaoa_malicious_variation(i)
        qaoa_malicious_circuits[f"qaoa_malicious_{i}"] = circuit
    

.. code:: ipython3

    # --------------------------------------------------
    # Run & Save Malicious QAOA Circuits on IBM Backend
    # --------------------------------------------------
    
    # Create folders for visuals
    os.makedirs("qaoa_malicious_diagrams", exist_ok=True)
    os.makedirs("qaoa_malicious_histograms", exist_ok=True)
    
    results_summary_qaoa_malicious = []
    
    for i in range(10):
        circuit_name = f"qaoa_malicious_{i}"
        circuit = qaoa_malicious_circuits[circuit_name]
    
        # Transpile and run on backend
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract measurement counts
        counts = result[0].data.meas.get_counts()
        success_state = max(counts, key=counts.get)
        percentage = counts[success_state] / sum(counts.values()) * 100
    
        # Save diagram
        circuit.draw("mpl", filename=f"qaoa_malicious_diagrams/{circuit_name}.png")
    
        # Save histogram
        fig = plot_histogram(counts, title=f"{circuit_name} | {percentage:.2f}% success")
        fig.savefig(f"qaoa_malicious_histograms/{circuit_name}_histogram.png")
        plt.show()
    
        # Store summary
        results_summary_qaoa_malicious.append({
            "name": circuit_name,
            "success_state": success_state,
            "success_rate": percentage
        })
    
    # Print summary
    for res in results_summary_qaoa_malicious:
        print(f"{res['name']} | State: {res['success_state']} | Success Rate: {res['success_rate']:.2f}%")
    



.. image:: output_10_0.png



.. image:: output_10_1.png



.. image:: output_10_2.png



.. image:: output_10_3.png



.. image:: output_10_4.png



.. image:: output_10_5.png



.. image:: output_10_6.png



.. image:: output_10_7.png



.. image:: output_10_8.png



.. image:: output_10_9.png



.. image:: output_10_10.png



.. image:: output_10_11.png



.. image:: output_10_12.png



.. image:: output_10_13.png



.. image:: output_10_14.png



.. image:: output_10_15.png



.. image:: output_10_16.png



.. image:: output_10_17.png



.. image:: output_10_18.png



.. image:: output_10_19.png


.. parsed-literal::

    qaoa_malicious_0 | State: 001 | Success Rate: 32.03%
    qaoa_malicious_1 | State: 011 | Success Rate: 18.73%
    qaoa_malicious_2 | State: 000 | Success Rate: 39.89%
    qaoa_malicious_3 | State: 010 | Success Rate: 15.60%
    qaoa_malicious_4 | State: 101 | Success Rate: 19.87%
    qaoa_malicious_5 | State: 010 | Success Rate: 13.45%
    qaoa_malicious_6 | State: 001 | Success Rate: 31.86%
    qaoa_malicious_7 | State: 100 | Success Rate: 19.38%
    qaoa_malicious_8 | State: 000 | Success Rate: 36.43%
    qaoa_malicious_9 | State: 101 | Success Rate: 19.09%
    

.. code:: ipython3

    # --------------------------------------------------
    # Feature Extraction & Save: Malicious QAOA Circuits
    # --------------------------------------------------
    
    qaoa_malicious_dataset = []
    
    # Loop through malicious QAOA circuits
    for i in range(10):
        name = f"qaoa_malicious_{i}"
        circuit = qaoa_malicious_circuits[name]
    
        # Transpile and run
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract and collect features
        features = extract_qaoa_features(name, circuit, result, label=1)
        qaoa_malicious_dataset.append(features)
    
    # Convert to DataFrame
    df_qaoa_malicious = pd.DataFrame(qaoa_malicious_dataset)
    
    # Display and export
    print(df_qaoa_malicious)
    df_qaoa_malicious.to_csv("qaoa_malicious_dataset.csv", index=False)
    


.. parsed-literal::

                   name  depth  cx  h  x  rx  rz  ccx  total_gates  success_rate  \
    0  qaoa_malicious_0     14   7  3  1   3   3    0           21     32.983398   
    1  qaoa_malicious_1     14   6  3  0   3   3    1           21     21.435547   
    2  qaoa_malicious_2     13   7  3  0   4   3    0           21     38.720703   
    3  qaoa_malicious_3     14   6  3  1   3   3    0           21     18.725586   
    4  qaoa_malicious_4     14   7  3  0   3   3    1           21     32.104492   
    5  qaoa_malicious_5     13   6  3  0   4   3    0           21     13.232422   
    6  qaoa_malicious_6     14   7  3  1   3   3    0           21     31.542969   
    7  qaoa_malicious_7     14   6  3  0   3   3    1           21     19.921875   
    8  qaoa_malicious_8     13   7  3  0   4   3    0           21     39.453125   
    9  qaoa_malicious_9     14   6  3  1   3   3    0           21     19.433594   
    
        entropy  unique_states  label  
    0  2.532378              8      1  
    1  2.855922              8      1  
    2  2.156543              8      1  
    3  2.928285              8      1  
    4  2.673185              8      1  
    5  2.998686              8      1  
    6  2.591494              8      1  
    7  2.914473              8      1  
    8  2.146537              8      1  
    9  2.943095              8      1  
    

.. code:: ipython3

    # --------------------------------------------------
    # Merge Clean + Malicious QAOA Datasets
    # --------------------------------------------------
    
    # Combine datasets
    df_qaoa_combined = pd.concat([df_qaoa_clean, df_qaoa_malicious], ignore_index=True)
    
    # Save merged dataset
    df_qaoa_combined.to_csv("qaoa_full_dataset.csv", index=False)
    
    # Display preview
    print("Combined QAOA Dataset (Clean + Malicious):")
    print(df_qaoa_combined.head(4))
    


.. parsed-literal::

    Combined QAOA Dataset (Clean + Malicious):
               name  depth  cx  h  x  rx  rz  ccx  total_gates  success_rate  \
    0  qaoa_clean_0     12   6  3  0   3   3    0           19     22.534180   
    1  qaoa_clean_1     12   6  3  0   3   3    0           19     30.786133   
    2  qaoa_clean_2     12   6  3  0   3   3    0           19     34.838867   
    3  qaoa_clean_3     12   6  3  0   3   3    0           19     16.870117   
    
        entropy  unique_states  label  
    0  2.756504              8      0  
    1  2.670489              8      0  
    2  2.363559              8      0  
    3  2.948300              8      0  
    

.. code:: ipython3

    # --------------------------------------------------
    # Dataset Analysis: Class Balance & Feature Correlation – QAOA
    # --------------------------------------------------
    
    # Create folder for plots
    os.makedirs("qaoa_analysis_plots", exist_ok=True)
    
    # ---------- CLASS BALANCE ----------
    label_counts = df_qaoa_combined['label'].value_counts().sort_index()
    label_df = pd.DataFrame({
        'Label': ['Clean', 'Malicious'],
        'Count': label_counts.values
    })
    
    # Plot class distribution
    plt.figure(figsize=(6, 4))
    sns.barplot(x='Label', y='Count', data=label_df, palette='Set2')
    plt.title("Class Balance: Clean (0) vs Malicious (1) – QAOA")
    plt.xlabel("Class Label")
    plt.ylabel("Number of Samples")
    plt.tight_layout()
    plt.savefig("qaoa_analysis_plots/qaoa_class_balance.png")
    plt.show()
    
    # ---------- FEATURE CORRELATION HEATMAP ----------
    # Drop non-numeric or constant columns
    numeric_df = df_qaoa_combined.drop(columns=["name"])
    numeric_df = numeric_df.loc[:, numeric_df.std() > 0]
    
    # Compute correlation matrix
    correlation = numeric_df.corr()
    
    # Plot heatmap
    plt.figure(figsize=(10, 8))
    sns.heatmap(
        correlation,
        annot=True,
        fmt=".2f",
        cmap="coolwarm",
        linewidths=0.5,
        linecolor='gray',
        square=True,
        cbar_kws={'shrink': 0.8},
        annot_kws={"size": 9}
    )
    
    plt.title("Feature Correlation Heatmap – QAOA Circuits", fontsize=14)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    plt.savefig("qaoa_analysis_plots/qaoa_feature_correlation_heatmap.png", dpi=300)
    plt.show()
    


.. parsed-literal::

    C:\Users\zeesh\AppData\Local\Temp\ipykernel_36392\3543010956.py:17: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x='Label', y='Count', data=label_df, palette='Set2')
    


.. image:: output_13_1.png



.. image:: output_13_2.png


