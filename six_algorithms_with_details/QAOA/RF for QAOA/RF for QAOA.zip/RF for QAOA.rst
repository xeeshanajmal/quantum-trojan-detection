.. code:: ipython3

    # -------------------------------------------------------------------------
    # QAOA Circuit Classification using Random Forest (Qiskit Dataset)
    # -------------------------------------------------------------------------
    
    # This notebook trains and evaluates a Random Forest classifier
    # to distinguish between clean and malicious QAOA quantum circuits.
    
    # Dataset:
    # - qaoa_full_dataset.csv (20 samples: 10 clean, 10 malicious)
    # - Features include: depth, gate counts, entropy, success rate, output variance
    # - Labels: 0 = clean, 1 = malicious
    
    # Objective:
    # - Benchmark Random Forest performance on structural + behavioral features
    # - Visualize classification metrics: accuracy, confusion matrix, ROC curve
    # - Identify key features for QAOA Trojan detection
    
    # Author: Zeeshan Ajmal
    

.. code:: ipython3

    import pandas as pd
    import numpy as np
    from sklearn.model_selection import train_test_split
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score, roc_curve
    import matplotlib.pyplot as plt
    import seaborn as sns
    
    sns.set(style="whitegrid")
    

.. code:: ipython3

    df_qaoa = pd.read_csv("qaoa_full_dataset.csv")
    
    print("Dataset shape:", df_qaoa.shape)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    display(df_qaoa)
    
    X = df_qaoa.drop(columns=["name", "label"])
    y = df_qaoa["label"]
    
    print("Class Distribution:")
    print(y.value_counts())
    


.. parsed-literal::

    Dataset shape: (20, 13)
    


.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>depth</th>
          <th>cx</th>
          <th>h</th>
          <th>x</th>
          <th>rx</th>
          <th>rz</th>
          <th>ccx</th>
          <th>total_gates</th>
          <th>success_rate</th>
          <th>entropy</th>
          <th>unique_states</th>
          <th>label</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>qaoa_clean_0</td>
          <td>12</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>19</td>
          <td>22.534180</td>
          <td>2.756504</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>qaoa_clean_1</td>
          <td>12</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>19</td>
          <td>30.786133</td>
          <td>2.670489</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>qaoa_clean_2</td>
          <td>12</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>19</td>
          <td>34.838867</td>
          <td>2.363559</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>qaoa_clean_3</td>
          <td>12</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>19</td>
          <td>16.870117</td>
          <td>2.948300</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>qaoa_clean_4</td>
          <td>12</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>19</td>
          <td>36.914062</td>
          <td>2.238368</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>5</th>
          <td>qaoa_clean_5</td>
          <td>12</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>19</td>
          <td>32.861328</td>
          <td>2.686598</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>6</th>
          <td>qaoa_clean_6</td>
          <td>12</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>19</td>
          <td>23.730469</td>
          <td>2.759173</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>7</th>
          <td>qaoa_clean_7</td>
          <td>12</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>19</td>
          <td>13.623047</td>
          <td>2.998479</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>8</th>
          <td>qaoa_clean_8</td>
          <td>12</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>19</td>
          <td>17.211914</td>
          <td>2.850210</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>9</th>
          <td>qaoa_clean_9</td>
          <td>12</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>19</td>
          <td>30.981445</td>
          <td>2.640481</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>10</th>
          <td>qaoa_malicious_0</td>
          <td>14</td>
          <td>7</td>
          <td>3</td>
          <td>1</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>21</td>
          <td>32.983398</td>
          <td>2.532378</td>
          <td>8</td>
          <td>1</td>
        </tr>
        <tr>
          <th>11</th>
          <td>qaoa_malicious_1</td>
          <td>14</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>1</td>
          <td>21</td>
          <td>21.435547</td>
          <td>2.855922</td>
          <td>8</td>
          <td>1</td>
        </tr>
        <tr>
          <th>12</th>
          <td>qaoa_malicious_2</td>
          <td>13</td>
          <td>7</td>
          <td>3</td>
          <td>0</td>
          <td>4</td>
          <td>3</td>
          <td>0</td>
          <td>21</td>
          <td>38.720703</td>
          <td>2.156543</td>
          <td>8</td>
          <td>1</td>
        </tr>
        <tr>
          <th>13</th>
          <td>qaoa_malicious_3</td>
          <td>14</td>
          <td>6</td>
          <td>3</td>
          <td>1</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>21</td>
          <td>18.725586</td>
          <td>2.928285</td>
          <td>8</td>
          <td>1</td>
        </tr>
        <tr>
          <th>14</th>
          <td>qaoa_malicious_4</td>
          <td>14</td>
          <td>7</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>1</td>
          <td>21</td>
          <td>32.104492</td>
          <td>2.673185</td>
          <td>8</td>
          <td>1</td>
        </tr>
        <tr>
          <th>15</th>
          <td>qaoa_malicious_5</td>
          <td>13</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>4</td>
          <td>3</td>
          <td>0</td>
          <td>21</td>
          <td>13.232422</td>
          <td>2.998686</td>
          <td>8</td>
          <td>1</td>
        </tr>
        <tr>
          <th>16</th>
          <td>qaoa_malicious_6</td>
          <td>14</td>
          <td>7</td>
          <td>3</td>
          <td>1</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>21</td>
          <td>31.542969</td>
          <td>2.591494</td>
          <td>8</td>
          <td>1</td>
        </tr>
        <tr>
          <th>17</th>
          <td>qaoa_malicious_7</td>
          <td>14</td>
          <td>6</td>
          <td>3</td>
          <td>0</td>
          <td>3</td>
          <td>3</td>
          <td>1</td>
          <td>21</td>
          <td>19.921875</td>
          <td>2.914473</td>
          <td>8</td>
          <td>1</td>
        </tr>
        <tr>
          <th>18</th>
          <td>qaoa_malicious_8</td>
          <td>13</td>
          <td>7</td>
          <td>3</td>
          <td>0</td>
          <td>4</td>
          <td>3</td>
          <td>0</td>
          <td>21</td>
          <td>39.453125</td>
          <td>2.146537</td>
          <td>8</td>
          <td>1</td>
        </tr>
        <tr>
          <th>19</th>
          <td>qaoa_malicious_9</td>
          <td>14</td>
          <td>6</td>
          <td>3</td>
          <td>1</td>
          <td>3</td>
          <td>3</td>
          <td>0</td>
          <td>21</td>
          <td>19.433594</td>
          <td>2.943095</td>
          <td>8</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    </div>


.. parsed-literal::

    Class Distribution:
    label
    0    10
    1    10
    Name: count, dtype: int64
    

.. code:: ipython3

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    print("Training set shape:", X_train.shape)
    print("Testing set shape:", X_test.shape)
    


.. parsed-literal::

    Training set shape: (16, 11)
    Testing set shape: (4, 11)
    

.. code:: ipython3

    rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_model.fit(X_train_scaled, y_train)
    
    y_pred = rf_model.predict(X_test_scaled)
    y_proba = rf_model.predict_proba(X_test_scaled)[:, 1]
    

.. code:: ipython3

    # --------------------------------------------------
    # Evaluate Model Performance and Save to Text
    # --------------------------------------------------
    
    from sklearn.metrics import accuracy_score, classification_report, roc_auc_score
    
    # Accuracy & AUC
    accuracy = accuracy_score(y_test, y_pred)
    roc_auc = roc_auc_score(y_test, y_proba)
    
    # Print results
    print(f"✅ Accuracy: {accuracy:.2f}")
    print(f"✅ ROC AUC Score: {roc_auc:.2f}\n")
    print("🧾 Classification Report:\n")
    print(classification_report(y_test, y_pred, target_names=["Clean", "Malicious"]))
    
    # Save evaluation metrics to text file
    with open("qaoa_rf_metrics.txt", "w") as f:
        f.write(f"Accuracy: {accuracy:.2f}\n")
        f.write(f"ROC AUC Score: {roc_auc:.2f}\n\n")
        f.write("Classification Report:\n")
        f.write(classification_report(y_test, y_pred, target_names=["Clean", "Malicious"]))
    


.. parsed-literal::

    ✅ Accuracy: 1.00
    ✅ ROC AUC Score: 1.00
    
    🧾 Classification Report:
    
                  precision    recall  f1-score   support
    
           Clean       1.00      1.00      1.00         2
       Malicious       1.00      1.00      1.00         2
    
        accuracy                           1.00         4
       macro avg       1.00      1.00      1.00         4
    weighted avg       1.00      1.00      1.00         4
    
    

.. code:: ipython3

    # --------------------------------------------------
    # Confusion Matrix and ROC Curve Visualization
    # --------------------------------------------------
    
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=["Clean", "Malicious"], yticklabels=["Clean", "Malicious"])
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.title("Confusion Matrix – QAOA Circuits (RF)")
    plt.tight_layout()
    plt.savefig("qaoa_rf_confusion_matrix.png", dpi=300)
    plt.show()
    
    # ROC curve
    fpr, tpr, thresholds = roc_curve(y_test, y_proba)
    plt.figure(figsize=(6, 4))
    plt.plot(fpr, tpr, label=f"ROC AUC = {roc_auc:.2f}")
    plt.plot([0, 1], [0, 1], linestyle='--', color='gray')
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve – QAOA Circuits (RF)")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("qaoa_rf_roc_curve.png", dpi=300)
    plt.show()
    



.. image:: output_6_0.png



.. image:: output_6_1.png


.. code:: ipython3

    # --------------------------------------------------
    # Feature Importance Visualization – Random Forest
    # --------------------------------------------------
    
    # Get feature names and importances
    feature_names = X.columns
    importances = rf_model.feature_importances_
    
    # Create DataFrame for sorting
    feature_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': importances
    }).sort_values(by='Importance', ascending=False)
    
    # Plot
    plt.figure(figsize=(8, 5))
    sns.barplot(x="Importance", y="Feature", data=feature_df, palette="viridis")
    plt.title("Feature Importance – QAOA Circuit Classification (RF)")
    plt.xlabel("Feature Weight")
    plt.ylabel("Feature")
    plt.tight_layout()
    plt.savefig("qaoa_rf_feature_importance.png", dpi=300)
    plt.show()
    
    # Display raw values
    print(feature_df)
    
    # Optional: also save as .txt for LaTeX or thesis appendix
    feature_df.to_string(buf=open("qaoa_rf_feature_importance.txt", "w"))
    


.. parsed-literal::

    C:\Users\zeesh\AppData\Local\Temp\ipykernel_33360\2715975255.py:17: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x="Importance", y="Feature", data=feature_df, palette="viridis")
    


.. image:: output_7_1.png


.. parsed-literal::

              Feature  Importance
    7     total_gates    0.432846
    0           depth    0.359757
    8    success_rate    0.044122
    1              cx    0.039049
    9         entropy    0.037112
    3               x    0.035941
    4              rx    0.029926
    6             ccx    0.021248
    2               h    0.000000
    5              rz    0.000000
    10  unique_states    0.000000
    

