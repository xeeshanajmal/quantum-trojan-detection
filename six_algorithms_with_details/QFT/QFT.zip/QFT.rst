.. code:: ipython3

    # ---------------------------------------------------------------
    # QFT Algorithm – Clean vs Malicious Dataset (Qiskit Simulation)
    # ---------------------------------------------------------------
    
    # This notebook implements the Quantum Fourier Transform (QFT)
    # using Qiskit, simulating both clean and malicious circuits to
    # generate a labeled dataset for anomaly and Trojan detection.
    
    # Objective:
    # - Generate 10 clean QFT circuits (valid QFT circuits on 3 qubits)
    # - Generate 10 malicious QFT circuits with structural tampering
    # - Extract structural and behavioral features for ML analysis
    
    # Dataset Composition:
    # - Clean class labeled as 0
    # - Malicious class labeled as 1
    # - Each record includes circuit complexity + output behavior
    
    # Threat Simulation in Malicious Circuits:
    # - Extra phase shifts or swaps
    # - Dropped controlled rotations
    # - Gate misalignments or redundant logic
    # - Inverse QFT applied partially
    
    # Tools Used:
    # - Qiskit Runtime + IBM backend
    # - matplotlib, seaborn, pandas, numpy
    # - Gate count, entropy, success state, circuit depth
    
    # Output:
    # - Diagrams, histograms, features, merged dataset, heatmap
    
    # Author: Zeeshan Ajmal
    

.. code:: ipython3

    # --------------------------------------------------
    # Qiskit + Runtime + Visualization + Utilities Setup
    # --------------------------------------------------
    
    # Core Qiskit
    from qiskit import QuantumCircuit, transpile
    from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as norm_sampler
    
    # Visualization
    %matplotlib inline
    from qiskit.visualization import plot_histogram, plot_circuit_layout
    import matplotlib.pyplot as plt
    import seaborn as sns
    
    # Data handling
    import numpy as np
    import pandas as pd
    from scipy.stats import entropy as shannon_entropy
    import os
    
    # Qiskit Runtime Service
    service = QiskitRuntimeService(
        channel='ibm_quantum',
        instance='ibm-q/open/main',
        token='ff1dde434d0dcec5608d0b0166f3df690e5b8258114b55d50805fe2c5c25d03a520f7551cd363d5295b421ab19908870fc00cdfb57a074f0a7eaa6c9ff2fa9e6'
    )
    
    # Backend selection
    backend = service.backend("ibm_brisbane")
    

.. code:: ipython3

    # --------------------------------------------------
    # Function: Generate Clean QFT Circuit
    # --------------------------------------------------
    
    def generate_qft_clean_variation(index):
        """
        Generate a clean 3-qubit QFT circuit.
        Variations are introduced via small angle tweaks for generality.
        """
        n = 3
        qc = QuantumCircuit(n)
    
        # Apply QFT with small phase shifts variation per index
        for j in range(n):
            qc.h(j)
            for k in range(j + 1, n):
                angle = np.pi / (2 ** (k - j)) + (index * 0.01)
                qc.cp(angle, k, j)
    
        # Swap qubits for QFT order
        qc.swap(0, 2)
    
        # Final measurement
        qc.measure_all()
    
        return qc
    

.. code:: ipython3

    # --------------------------------------------------
    # Generate & Store Clean QFT Circuit Variants
    # --------------------------------------------------
    
    # Dictionary to hold clean QFT circuits
    qft_clean_circuits = {}
    
    # Generate 10 clean variations
    for i in range(10):
        circuit = generate_qft_clean_variation(i)
        qft_clean_circuits[f"qft_clean_{i}"] = circuit
    

.. code:: ipython3

    # --------------------------------------------------
    # Simulate, Visualize, and Store Clean QFT Outputs
    # --------------------------------------------------
    
    # Create folders for outputs
    os.makedirs("qft_clean_diagrams", exist_ok=True)
    os.makedirs("qft_clean_histograms", exist_ok=True)
    
    results_summary_qft_clean = []
    
    for i in range(10):
        circuit_name = f"qft_clean_{i}"
        circuit = qft_clean_circuits[circuit_name]
    
        # Transpile and execute on IBM backend
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract output counts
        counts = result[0].data.meas.get_counts()
        success_state = max(counts, key=counts.get)
        percentage = counts[success_state] / sum(counts.values()) * 100
    
        # Save circuit diagram
        circuit.draw("mpl", filename=f"qft_clean_diagrams/{circuit_name}.png")
    
        # Save histogram
        fig = plot_histogram(counts, title=f"{circuit_name} | {percentage:.2f}% success")
        fig.savefig(f"qft_clean_histograms/{circuit_name}_histogram.png")
        plt.show()
    
        # Record results
        results_summary_qft_clean.append({
            "name": circuit_name,
            "success_state": success_state,
            "success_rate": percentage
        })
    
    # Show all results
    for res in results_summary_qft_clean:
        print(f"{res['name']} | State: {res['success_state']} | Success Rate: {res['success_rate']:.2f}%")
    



.. image:: output_4_0.png



.. image:: output_4_1.png



.. image:: output_4_2.png



.. image:: output_4_3.png



.. image:: output_4_4.png



.. image:: output_4_5.png



.. image:: output_4_6.png



.. image:: output_4_7.png



.. image:: output_4_8.png



.. image:: output_4_9.png



.. image:: output_4_10.png



.. image:: output_4_11.png



.. image:: output_4_12.png



.. image:: output_4_13.png



.. image:: output_4_14.png



.. image:: output_4_15.png



.. image:: output_4_16.png



.. image:: output_4_17.png



.. image:: output_4_18.png



.. image:: output_4_19.png


.. parsed-literal::

    qft_clean_0 | State: 011 | Success Rate: 13.92%
    qft_clean_1 | State: 101 | Success Rate: 13.28%
    qft_clean_2 | State: 011 | Success Rate: 14.18%
    qft_clean_3 | State: 010 | Success Rate: 16.50%
    qft_clean_4 | State: 001 | Success Rate: 13.99%
    qft_clean_5 | State: 011 | Success Rate: 16.75%
    qft_clean_6 | State: 101 | Success Rate: 12.96%
    qft_clean_7 | State: 010 | Success Rate: 16.89%
    qft_clean_8 | State: 111 | Success Rate: 14.14%
    qft_clean_9 | State: 010 | Success Rate: 19.02%
    

.. code:: ipython3

    # --------------------------------------------------
    # Feature Extraction for QFT Circuits
    # --------------------------------------------------
    
    def extract_qft_features(circuit_name, circuit, result, label):
        # Structural features
        ops = circuit.count_ops()
        num_cx = ops.get('cx', 0)
        num_h = ops.get('h', 0)
        num_x = ops.get('x', 0)
        num_ccx = ops.get('ccx', 0)
        num_cp = ops.get('cp', 0)
        num_swap = ops.get('swap', 0)
        depth = circuit.depth()
        total_gates = sum(ops.values())
    
        # Measurement-based features
        counts = result[0].data.meas.get_counts()
        probs = np.array(list(counts.values()))
        probs = probs / probs.sum()
    
        success_state = max(counts, key=counts.get)
        success_rate = counts[success_state] / sum(counts.values()) * 100
        entropy = shannon_entropy(probs, base=2)
        unique_states = len(counts)
    
        return {
            "name": circuit_name,
            "depth": depth,
            "cx": num_cx,
            "h": num_h,
            "x": num_x,
            "cp": num_cp,
            "swap": num_swap,
            "ccx": num_ccx,
            "total_gates": total_gates,
            "success_rate": success_rate,
            "entropy": entropy,
            "unique_states": unique_states,
            "label": label
        }
    

.. code:: ipython3

    # --------------------------------------------------
    # Feature Extraction & Save: Clean QFT Circuits
    # --------------------------------------------------
    
    qft_clean_dataset = []
    
    # Loop through all clean QFT circuits
    for i in range(10):
        name = f"qft_clean_{i}"
        circuit = qft_clean_circuits[name]
    
        # Transpile and execute
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract and collect features
        features = extract_qft_features(name, circuit, result, label=0)
        qft_clean_dataset.append(features)
    
    # Convert to DataFrame
    df_qft_clean = pd.DataFrame(qft_clean_dataset)
    
    # Display and export
    print(df_qft_clean)
    df_qft_clean.to_csv("qft_clean_dataset.csv", index=False)
    


.. parsed-literal::

              name  depth  cx  h  x  cp  swap  ccx  total_gates  success_rate  \
    0  qft_clean_0      7   0  3  0   3     1    0           11     17.138672   
    1  qft_clean_1      7   0  3  0   3     1    0           11     13.305664   
    2  qft_clean_2      7   0  3  0   3     1    0           11     13.647461   
    3  qft_clean_3      7   0  3  0   3     1    0           11     16.406250   
    4  qft_clean_4      7   0  3  0   3     1    0           11     14.086914   
    5  qft_clean_5      7   0  3  0   3     1    0           11     14.501953   
    6  qft_clean_6      7   0  3  0   3     1    0           11     14.111328   
    7  qft_clean_7      7   0  3  0   3     1    0           11     16.113281   
    8  qft_clean_8      7   0  3  0   3     1    0           11     17.333984   
    9  qft_clean_9      7   0  3  0   3     1    0           11     18.334961   
    
        entropy  unique_states  label  
    0  2.961856              8      0  
    1  2.998712              8      0  
    2  2.997213              8      0  
    3  2.960628              8      0  
    4  2.995166              8      0  
    5  2.994000              8      0  
    6  2.997026              8      0  
    7  2.972666              8      0  
    8  2.939034              8      0  
    9  2.944496              8      0  
    

.. code:: ipython3

    # --------------------------------------------------
    # Malicious QFT Circuit Generation (Trojan Simulation)
    # --------------------------------------------------
    
    # This section generates 10 tampered QFT circuits to simulate Trojan attacks
    # or adversarial logic manipulation in structured quantum transforms.
    
    # Attack Simulation Strategies:
    # 1. Phase Tampering: Modify controlled-phase gate angles
    # 2. Entanglement Corruption: Remove or misroute CP or SWAP gates
    # 3. Trojan Insertion: Inject extra gates post-transform (e.g., X, CX, CCX)
    # 4. Structural Flip: Change QFT ordering by skipping swaps or reordering
    
    # Objectives:
    # - Create visually similar but logically altered QFT circuits
    # - Mislead or degrade quantum information processing
    # - All outputs are labeled `1` (malicious class)
    
    # These variations are vital to evaluating anomaly detection methods in
    # structured, reversible quantum subroutines like QFT.
    
    

.. code:: ipython3

    # --------------------------------------------------
    # Function: Generate Malicious QFT Circuit
    # --------------------------------------------------
    
    def generate_qft_malicious_variation(index):
        """
        Generate a malicious variation of a 3-qubit QFT circuit.
        Injects Trojan behavior via corrupted phase gates, gate injections,
        or by omitting/swapping critical operations.
        """
        n = 3
        qc = QuantumCircuit(n)
    
        # Malicious QFT with altered logic
        for j in range(n):
            qc.h(j)
    
            for k in range(j + 1, n):
                # Altered phase angle
                altered_angle = np.pi / (2 ** (k - j)) + ((-1) ** k) * 0.2
                qc.cp(altered_angle, k, j)
    
                # Extra gate injection
                if index % 3 == 0 and j == 0:
                    qc.x(j)
                elif index % 3 == 1 and k == 2:
                    qc.cx(0, 2)
                elif index % 3 == 2:
                    qc.ccx(0, 1, 2)
    
        # Trojan: Remove or replace swaps
        if index % 2 == 0:
            # Omit swap
            pass
        else:
            # Swap alternative (misroute)
            qc.swap(1, 2)
    
        # Final measurement
        qc.measure_all()
    
        return qc
    

.. code:: ipython3

    # --------------------------------------------------
    # Generate & Store All Malicious QFT Circuit Variants
    # --------------------------------------------------
    
    # Dictionary to hold malicious QFT circuits
    qft_malicious_circuits = {}
    
    # Generate 10 malicious variations
    for i in range(10):
        circuit = generate_qft_malicious_variation(i)
        qft_malicious_circuits[f"qft_malicious_{i}"] = circuit
    

.. code:: ipython3

    # --------------------------------------------------
    # Run & Save Malicious QFT Circuits on IBM Backend
    # --------------------------------------------------
    
    # Create folders for visualizations
    os.makedirs("qft_malicious_diagrams", exist_ok=True)
    os.makedirs("qft_malicious_histograms", exist_ok=True)
    
    results_summary_qft_malicious = []
    
    for i in range(10):
        circuit_name = f"qft_malicious_{i}"
        circuit = qft_malicious_circuits[circuit_name]
    
        # Transpile and run
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Get output statistics
        counts = result[0].data.meas.get_counts()
        success_state = max(counts, key=counts.get)
        percentage = counts[success_state] / sum(counts.values()) * 100
    
        # Save circuit diagram
        circuit.draw("mpl", filename=f"qft_malicious_diagrams/{circuit_name}.png")
    
        # Save histogram
        fig = plot_histogram(counts, title=f"{circuit_name} | {percentage:.2f}% success")
        fig.savefig(f"qft_malicious_histograms/{circuit_name}_histogram.png")
        plt.show()
    
        # Save result summary
        results_summary_qft_malicious.append({
            "name": circuit_name,
            "success_state": success_state,
            "success_rate": percentage
        })
    
    # Display summaries
    for res in results_summary_qft_malicious:
        print(f"{res['name']} | State: {res['success_state']} | Success Rate: {res['success_rate']:.2f}%")
    



.. image:: output_10_0.png



.. image:: output_10_1.png



.. image:: output_10_2.png



.. image:: output_10_3.png



.. image:: output_10_4.png



.. image:: output_10_5.png



.. image:: output_10_6.png



.. image:: output_10_7.png



.. image:: output_10_8.png



.. image:: output_10_9.png



.. image:: output_10_10.png



.. image:: output_10_11.png



.. image:: output_10_12.png



.. image:: output_10_13.png



.. image:: output_10_14.png



.. image:: output_10_15.png



.. image:: output_10_16.png



.. image:: output_10_17.png



.. image:: output_10_18.png



.. image:: output_10_19.png


.. parsed-literal::

    qft_malicious_0 | State: 100 | Success Rate: 20.17%
    qft_malicious_1 | State: 010 | Success Rate: 15.99%
    qft_malicious_2 | State: 111 | Success Rate: 19.19%
    qft_malicious_3 | State: 110 | Success Rate: 14.82%
    qft_malicious_4 | State: 111 | Success Rate: 16.21%
    qft_malicious_5 | State: 011 | Success Rate: 19.38%
    qft_malicious_6 | State: 010 | Success Rate: 14.43%
    qft_malicious_7 | State: 100 | Success Rate: 16.70%
    qft_malicious_8 | State: 011 | Success Rate: 26.64%
    qft_malicious_9 | State: 100 | Success Rate: 15.58%
    

.. code:: ipython3

    # --------------------------------------------------
    # Feature Extraction & Save: Malicious QFT Circuits
    # --------------------------------------------------
    
    qft_malicious_dataset = []
    
    # Loop through all malicious QFT circuits
    for i in range(10):
        name = f"qft_malicious_{i}"
        circuit = qft_malicious_circuits[name]
    
        # Transpile and execute
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract features
        features = extract_qft_features(name, circuit, result, label=1)
        qft_malicious_dataset.append(features)
    
    # Convert to DataFrame
    df_qft_malicious = pd.DataFrame(qft_malicious_dataset)
    
    # Display and export
    print(df_qft_malicious)
    df_qft_malicious.to_csv("qft_malicious_dataset.csv", index=False)
    


.. parsed-literal::

                  name  depth  cx  h  x  cp  swap  ccx  total_gates  success_rate  \
    0  qft_malicious_0      7   0  3  2   3     0    0           12     14.843750   
    1  qft_malicious_1      9   2  3  0   3     1    0           13     15.893555   
    2  qft_malicious_2     10   0  3  0   3     0    3           13     19.165039   
    3  qft_malicious_3      8   0  3  2   3     1    0           13     22.924805   
    4  qft_malicious_4      8   2  3  0   3     0    0           12     13.647461   
    5  qft_malicious_5     11   0  3  0   3     1    3           14     18.920898   
    6  qft_malicious_6      7   0  3  2   3     0    0           12     21.826172   
    7  qft_malicious_7      9   2  3  0   3     1    0           13     13.842773   
    8  qft_malicious_8     10   0  3  0   3     0    3           13     19.604492   
    9  qft_malicious_9      8   0  3  2   3     1    0           13     14.648438   
    
        entropy  unique_states  label  
    0  2.989963              8      1  
    1  2.975786              8      1  
    2  2.867660              8      1  
    3  2.758180              8      1  
    4  2.998389              8      1  
    5  2.870630              8      1  
    6  2.828029              8      1  
    7  2.995983              8      1  
    8  2.860486              8      1  
    9  2.991022              8      1  
    

.. code:: ipython3

    # --------------------------------------------------
    # Merge Clean + Malicious QFT Datasets
    # --------------------------------------------------
    
    # Combine both datasets
    df_qft_combined = pd.concat([df_qft_clean, df_qft_malicious], ignore_index=True)
    
    # Save merged dataset
    df_qft_combined.to_csv("qft_full_dataset.csv", index=False)
    
    # Display preview
    print("Combined QFT Dataset (Clean + Malicious):")
    print(df_qft_combined.head(4))
    


.. parsed-literal::

    Combined QFT Dataset (Clean + Malicious):
              name  depth  cx  h  x  cp  swap  ccx  total_gates  success_rate  \
    0  qft_clean_0      7   0  3  0   3     1    0           11     17.138672   
    1  qft_clean_1      7   0  3  0   3     1    0           11     13.305664   
    2  qft_clean_2      7   0  3  0   3     1    0           11     13.647461   
    3  qft_clean_3      7   0  3  0   3     1    0           11     16.406250   
    
        entropy  unique_states  label  
    0  2.961856              8      0  
    1  2.998712              8      0  
    2  2.997213              8      0  
    3  2.960628              8      0  
    

.. code:: ipython3

    # --------------------------------------------------
    # Dataset Analysis: Class Balance & Feature Correlation – QFT
    # --------------------------------------------------
    
    # Create folder for plots
    os.makedirs("qft_analysis_plots", exist_ok=True)
    
    # ---------- CLASS BALANCE ----------
    label_counts = df_qft_combined['label'].value_counts().sort_index()
    label_df = pd.DataFrame({
        'Label': ['Clean', 'Malicious'],
        'Count': label_counts.values
    })
    
    # Plot class distribution
    plt.figure(figsize=(6, 4))
    sns.barplot(x='Label', y='Count', data=label_df, palette='Set2')
    plt.title("Class Balance: Clean (0) vs Malicious (1) – QFT")
    plt.xlabel("Class Label")
    plt.ylabel("Number of Samples")
    plt.tight_layout()
    plt.savefig("qft_analysis_plots/qft_class_balance.png")
    plt.show()
    
    # ---------- FEATURE CORRELATION HEATMAP ----------
    numeric_df = df_qft_combined.drop(columns=["name"])
    numeric_df = numeric_df.loc[:, numeric_df.std() > 0]  # Remove constant columns
    
    correlation = numeric_df.corr()
    
    plt.figure(figsize=(10, 8))
    sns.heatmap(
        correlation,
        annot=True,
        fmt=".2f",
        cmap="coolwarm",
        linewidths=0.5,
        linecolor='gray',
        square=True,
        cbar_kws={'shrink': 0.8},
        annot_kws={"size": 9}
    )
    
    plt.title("Feature Correlation Heatmap – QFT Circuits", fontsize=14)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)
    plt.tight_layout()
    plt.savefig("qft_analysis_plots/qft_feature_correlation_heatmap.png", dpi=300)
    plt.show()
    


.. parsed-literal::

    C:\Users\zeesh\AppData\Local\Temp\ipykernel_36744\3371045109.py:17: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x='Label', y='Count', data=label_df, palette='Set2')
    


.. image:: output_13_1.png



.. image:: output_13_2.png


