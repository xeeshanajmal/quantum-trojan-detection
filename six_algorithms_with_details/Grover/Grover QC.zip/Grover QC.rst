.. code:: ipython3

    # ---------------------------------------------------------------
    # Grover’s Algorithm – Clean vs Malicious Dataset (Qiskit Simulation)
    # ---------------------------------------------------------------
    
    # This notebook implements Grover’s quantum search algorithm using Qiskit,
    # simulating both clean and malicious circuit variants to build a dataset
    # for anomaly and Trojan detection in quantum computation.
    
    # Objective:
    # - Generate 10 clean Grover circuits with valid oracle & diffusion operations
    # - Generate 10 malicious Grover circuits containing subtle adversarial changes
    # - Simulate all circuits using IBM Qiskit Runtime and extract structural + output features
    
    # Dataset Composition:
    # - Clean circuits labeled as 0
    # - Malicious circuits labeled as 1
    # - Features include circuit depth, gate counts, entropy, and output success rate
    
    # Threat Model:
    # - Malicious variants include:
    #     • Incorrect oracles
    #     • Extra entangling gates (X, CX, CCX) inserted post-diffusion
    #     • Swap or gate reorderings that break amplitude amplification
    #     • Noisy layers mimicking decoherence
    
    # Visualization & Analysis:
    # - Each circuit saved with its diagram and histogram
    # - Dataset exported to CSV
    # - Class distribution and feature correlation visualized for model training
    
    # Environment:
    # - Qiskit + IBM Runtime
    # - Matplotlib, Seaborn, Pandas, NumPy for visualization and data handling
    
    # This notebook supports secure quantum computing research by modeling
    # optimization circuit behaviors under clean and adversarial settings.
    
    # Author: Zeeshan Ajmal

.. code:: ipython3

    # Core Qiskit imports
    from qiskit import QuantumCircuit, transpile, quantum_info
    from qiskit import schedule as build_schedule
    from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as norm_sampler
    
    # Visualization tools
    %matplotlib inline
    from qiskit.visualization import plot_histogram, plot_circuit_layout
    import matplotlib.pyplot as plt
    
    # Python utilities
    import functools
    

.. code:: ipython3

    # -----------------------------------------------
    # Initializing IBM Quantum Runtime Account
    # -----------------------------------------------
    
    from qiskit_ibm_runtime import QiskitRuntimeService
    
    service = QiskitRuntimeService(
        channel='ibm_quantum',
        instance='ibm-q/open/main',
        token='ff1dde434d0dcec5608d0b0166f3df690e5b8258114b55d50805fe2c5c25d03a520f7551cd363d5295b421ab19908870fc00cdfb57a074f0a7eaa6c9ff2fa9e6'
    )
    
    # Or save your credentials on disk.
    # QiskitRuntimeService.save_account(channel='ibm_quantum', instance='ibm-q/open/main', token='ff1dde434d0dcec5608d0b0166f3df690e5b8258114b55d50805fe2c5c25d03a520f7551cd363d5295b421ab19908870fc00cdfb57a074f0a7eaa6c9ff2fa9e6')
    
    # Author: Zeeshan
    

.. code:: ipython3

    # Function to generate Grover Clean circuit based on index variation
    def generate_grover_clean_variation(index):
        qc = QuantumCircuit(3)
    
        # Step 1: Superposition
        qc.h([0, 1, 2])
    
        # Step 2: Oracle (10 distinct targets)
        targets = [
            "000", "001", "010", "011", "100",
            "101", "110", "111", "custom1", "custom2"
        ]
    
        target = targets[index]
    
        if target == "000":
            qc.x([0, 1, 2])
            qc.ccx(0, 1, 2)
            qc.x([0, 1, 2])
        elif target == "001":
            qc.x([0, 1])
            qc.ccx(0, 1, 2)
            qc.x([0, 1])
        elif target == "010":
            qc.x([0, 2])
            qc.ccx(0, 1, 2)
            qc.x([0, 2])
        elif target == "011":
            qc.x([0])
            qc.ccx(0, 1, 2)
            qc.x([0])
        elif target == "100":
            qc.x([1, 2])
            qc.ccx(0, 1, 2)
            qc.x([1, 2])
        elif target == "101":
            qc.x([1])
            qc.ccx(0, 1, 2)
            qc.x([1])
        elif target == "110":
            qc.x([2])
            qc.ccx(0, 1, 2)
            qc.x([2])
        elif target == "111":
            qc.ccx(0, 1, 2)
        elif target == "custom1":
            qc.cz(0, 2)
        elif target == "custom2":
            qc.cz(1, 2)
    
        # Step 3: Grover Diffuser
        qc.h([0, 1, 2])
        qc.x([0, 1, 2])
        qc.h(2)
        qc.ccx(0, 1, 2)
        qc.h(2)
        qc.x([0, 1, 2])
        qc.h([0, 1, 2])
    
        # Step 4: Measurement
        qc.measure_all()
    
        return qc
    

.. code:: ipython3

    # Dictionary to hold clean Grover circuits
    grover_clean_circuits = {}
    
    # Generate 10 clean variations
    for i in range(10):
        grover_clean_circuits[f"grover_clean_{i}"] = generate_grover_clean_variation(i)
    

.. code:: ipython3

    # -----------------------------------------------
    # Run & Save Grover Clean Circuits (All Variations)
    # -----------------------------------------------
    from qiskit.visualization import plot_histogram
    import matplotlib.pyplot as plt
    from IPython.display import display
    import os
    
    # Create folders to store diagrams and histograms
    os.makedirs("grover_clean_diagrams", exist_ok=True)
    os.makedirs("grover_clean_histograms", exist_ok=True)
    
    results_summary = []
    backend = service.backend("ibm_brisbane")  # or any preferred backend
    
    for i in range(10):
        circuit_name = f"grover_clean_{i}"
        circuit = grover_clean_circuits[circuit_name]
    
        # Transpile & execute
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract counts and success rate
        counts = result[0].data.meas.get_counts()
        success_state = max(counts, key=counts.get)
        percentage = counts[success_state] / sum(counts.values()) * 100
    
        # Save circuit diagram
        circuit.draw("mpl", filename=f"grover_clean_diagrams/{circuit_name}.png")
        
        # Save histogram
        fig = plot_histogram(counts, title=f"{circuit_name} | {percentage:.2f}% success rate")
        fig.savefig(f"grover_clean_histograms/{circuit_name}_histogram.png")
        plt.show()
    
        # Store results
        results_summary.append({
            "name": circuit_name,
            "success_state": success_state,
            "success_rate": percentage
        })
    
    # Display summary
    for res in results_summary:
        print(f"{res['name']} | State: {res['success_state']} | Success Rate: {res['success_rate']:.2f}%")
    



.. image:: output_5_0.png



.. image:: output_5_1.png



.. image:: output_5_2.png



.. image:: output_5_3.png



.. image:: output_5_4.png



.. image:: output_5_5.png



.. image:: output_5_6.png



.. image:: output_5_7.png



.. image:: output_5_8.png



.. image:: output_5_9.png



.. image:: output_5_10.png



.. image:: output_5_11.png



.. image:: output_5_12.png



.. image:: output_5_13.png



.. image:: output_5_14.png



.. image:: output_5_15.png



.. image:: output_5_16.png



.. image:: output_5_17.png



.. image:: output_5_18.png



.. image:: output_5_19.png


.. parsed-literal::

    grover_clean_0 | State: 001 | Success Rate: 17.97%
    grover_clean_1 | State: 011 | Success Rate: 17.77%
    grover_clean_2 | State: 011 | Success Rate: 15.21%
    grover_clean_3 | State: 011 | Success Rate: 15.43%
    grover_clean_4 | State: 011 | Success Rate: 17.99%
    grover_clean_5 | State: 111 | Success Rate: 21.63%
    grover_clean_6 | State: 111 | Success Rate: 15.28%
    grover_clean_7 | State: 001 | Success Rate: 18.31%
    grover_clean_8 | State: 111 | Success Rate: 42.63%
    grover_clean_9 | State: 111 | Success Rate: 44.14%
    

.. code:: ipython3

    ## Dataset Feature Extraction – Grover Clean Circuits
    
    # In this section, we extract both structural and measurement-based features from each Grover clean circuit. These features will be used to train machine learning models to detect circuit tampering or quantum Trojans.
    
    # We collect:
    # - Structural features (gate counts, circuit depth)
    # - Measurement features (success rate, entropy, unique output states)
    # - A binary label (0 = clean, 1 = malicious)
    
    # The results will be saved as a Pandas DataFrame and exported to a CSV file.
    

.. code:: ipython3

    # Imports
    import pandas as pd
    import numpy as np
    from scipy.stats import entropy as shannon_entropy
    

.. code:: ipython3

    # Feature Extraction
    
    def extract_features(circuit_name, circuit, result, label):
        # Structural features
        ops = circuit.count_ops()
        num_cx = ops.get('cx', 0)
        num_h = ops.get('h', 0)
        num_x = ops.get('x', 0)
        num_ccx = ops.get('ccx', 0)
        depth = circuit.depth()
        total_gates = sum(ops.values())
    
        # Histogram to probability distribution
        counts = result[0].data.meas.get_counts()
        probs = np.array(list(counts.values()))
        probs = probs / probs.sum()
    
        # Measurement-based features
        success_state = max(counts, key=counts.get)
        success_rate = counts[success_state] / sum(counts.values()) * 100
        entropy = shannon_entropy(probs, base=2)
        unique_states = len(counts)
    
        return {
            "name": circuit_name,
            "depth": depth,
            "cx": num_cx,
            "h": num_h,
            "x": num_x,
            "ccx": num_ccx,
            "total_gates": total_gates,
            "success_rate": success_rate,
            "entropy": entropy,
            "unique_states": unique_states,
            "label": label
        }
    

.. code:: ipython3

    dataset = []
    
    # Loop through Grover clean circuits
    for i in range(10):
        name = f"grover_clean_{i}"
        circuit = grover_clean_circuits[name]
    
        # Run on backend
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract and collect features
        features = extract_features(name, circuit, result, label=0)
        dataset.append(features)
    
    # Convert to DataFrame
    df_clean = pd.DataFrame(dataset)
    
    # Display and export
    print(df_clean)
    df_clean.to_csv("grover_clean_dataset.csv", index=False)
    


.. parsed-literal::

                 name  depth  cx   h   x  ccx  total_gates  success_rate  \
    0  grover_clean_0     12   0  11  12    2           29     16.650391   
    1  grover_clean_1     11   0  11  10    2           27     18.359375   
    2  grover_clean_2     12   0  11  10    2           27     16.113281   
    3  grover_clean_3     11   0  11   8    2           25     18.945312   
    4  grover_clean_4     12   0  11  10    2           27     18.945312   
    5  grover_clean_5     11   0  11   8    2           25     18.188477   
    6  grover_clean_6     12   0  11   8    2           25     21.728516   
    7  grover_clean_7     10   0  11   6    2           23     17.456055   
    8  grover_clean_8     10   0  11   6    1           23     52.563477   
    9  grover_clean_9     10   0  11   6    1           23     45.288086   
    
        entropy  unique_states  label  
    0  2.923333              8      0  
    1  2.932354              8      0  
    2  2.985350              8      0  
    3  2.940776              8      0  
    4  2.937411              8      0  
    5  2.951969              8      0  
    6  2.918748              8      0  
    7  2.973883              8      0  
    8  1.619115              8      0  
    9  1.684894              8      0  
    

.. code:: ipython3

    # --------------------------------------------------
    # Malicious Grover Circuit Generation (Trojan Simulation)
    # --------------------------------------------------
    
    # This section constructs 10 adversarial Grover circuits that simulate
    # Trojan-like behaviors or logic faults targeting the oracle and amplification layers.
    
    # Attack Simulation Strategies:
    # 1. Oracle manipulation: Encode incorrect solution state or apply wrong logic
    # 2. Gate Injection: Add X, CX, or CCX gates after oracle or diffusion steps
    # 3. Amplitude distortion: Alter Hadamard or Z gates in the diffusion operator
    # 4. Over-entanglement: Entangle unintended qubits to create quantum interference
    # 5. Output noise: Post-processing injection to skew measured results
    
    # Objective:
    # - Maintain visual similarity to clean Grover circuits
    # - Induce functional degradation or quantum uncertainty
    # - Label all adversarial circuits as `1` (malicious) for classification
    
    # These tampered circuits enable evaluation of detection mechanisms against
    # quantum Trojans embedded in well-known quantum search protocols.
    

.. code:: ipython3

    # Function to generate malicious Grover circuit variation
    def generate_grover_malicious_variation(index):
        qc = QuantumCircuit(3)
    
        # Step 1: Superposition
        qc.h([0, 1, 2])
    
        # Step 2: Oracle - same as clean but targeted or corrupted
        if index % 4 == 0:
            qc.cz(0, 2)
        elif index % 4 == 1:
            qc.cz(1, 2)
        elif index % 4 == 2:
            qc.cz(0, 1)
        else:
            qc.ccx(0, 1, 2)
    
        # Step 3: Grover Diffuser (intentionally tampered)
        qc.x([0, 1, 2])
        qc.h(2)
        qc.ccx(0, 1, 2)
        qc.h(2)
        qc.x([0, 1, 2])
    
        # Step 4: Inject malicious gates
        if index % 3 == 0:
            qc.cx(1, 2)
        elif index % 3 == 1:
            qc.ccx(2, 0, 1)
        elif index % 3 == 2:
            qc.x(0)
            qc.x(1)
            qc.cx(0, 2)
    
        # Step 5: Measurement
        qc.measure_all()
    
        return qc
    

.. code:: ipython3

    # Dictionary to hold malicious Grover circuits
    grover_malicious_circuits = {}
    
    # Generate 10 malicious variations
    for i in range(10):
        grover_malicious_circuits[f"grover_malicious_{i}"] = generate_grover_malicious_variation(i)
    

.. code:: ipython3

    # Store malicious dataset
    malicious_dataset = []
    
    # Loop through all 10 malicious circuits
    for i in range(10):
        name = f"grover_malicious_{i}"
        circuit = grover_malicious_circuits[name]
    
        # Transpile and run on backend
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract features with label = 1 (malicious)
        features = extract_features(name, circuit, result, label=1)
        malicious_dataset.append(features)
    
    # Convert to DataFrame
    df_malicious = pd.DataFrame(malicious_dataset)
    print(df_malicious)
    
    # Export to CSV
    df_malicious.to_csv("grover_malicious_dataset.csv", index=False)
    


.. parsed-literal::

                     name  depth  cx  h  x  ccx  total_gates  success_rate  \
    0  grover_malicious_0      9   1  5  6    1           18     18.798828   
    1  grover_malicious_1      9   0  5  6    2           18     15.722656   
    2  grover_malicious_2      8   1  5  8    1           20     19.384766   
    3  grover_malicious_3      9   1  5  6    2           18     17.089844   
    4  grover_malicious_4      9   0  5  6    2           18     15.551758   
    5  grover_malicious_5      9   1  5  8    1           20     18.212891   
    6  grover_malicious_6      8   1  5  6    1           18     14.599609   
    7  grover_malicious_7      9   0  5  6    3           18     17.285156   
    8  grover_malicious_8      9   1  5  8    1           20     14.013672   
    9  grover_malicious_9      9   1  5  6    1           18     16.674805   
    
        entropy  unique_states  label  
    0  2.948157              8      1  
    1  2.963197              8      1  
    2  2.944280              8      1  
    3  2.957353              8      1  
    4  2.974604              8      1  
    5  2.964026              8      1  
    6  2.989420              8      1  
    7  2.976823              8      1  
    8  2.992562              8      1  
    9  2.972262              8      1  
    

.. code:: ipython3

    from IPython.display import display
    import os
    from qiskit.visualization import plot_histogram
    import matplotlib.pyplot as plt
    
    # Create folders if not exist
    os.makedirs("malicious_circuit_diagrams", exist_ok=True)
    os.makedirs("malicious_histograms", exist_ok=True)
    
    # Loop through malicious circuits
    for i in range(10):
        name = f"grover_malicious_{i}"
        circuit = grover_malicious_circuits[name]
    
        # Save and display circuit diagram
        circuit.draw("mpl", filename=f"malicious_circuit_diagrams/{name}.png")
        display(circuit.draw("mpl"))
    
        # Run circuit
        transpiled = transpile(circuit, backend=backend)
        sampler = norm_sampler(backend)
        job = sampler.run([transpiled])
        result = job.result()
    
        # Extract measurement counts
        counts = result[0].data.meas.get_counts()
        success_state = max(counts, key=counts.get)
        percentage = counts[success_state] / sum(counts.values()) * 100
    
        # Plot and save histogram
        fig = plot_histogram(counts, title=f"{name} | {percentage:.2f}% success")
        plt.show()
        fig.savefig(f"malicious_histograms/{name}_hist.png")
        plt.close(fig)
    



.. image:: output_14_0.png



.. image:: output_14_1.png



.. image:: output_14_2.png



.. image:: output_14_3.png



.. image:: output_14_4.png



.. image:: output_14_5.png



.. image:: output_14_6.png



.. image:: output_14_7.png



.. image:: output_14_8.png



.. image:: output_14_9.png



.. image:: output_14_10.png



.. image:: output_14_11.png



.. image:: output_14_12.png



.. image:: output_14_13.png



.. image:: output_14_14.png



.. image:: output_14_15.png



.. image:: output_14_16.png



.. image:: output_14_17.png



.. image:: output_14_18.png



.. image:: output_14_19.png



.. image:: output_14_20.png



.. image:: output_14_21.png



.. image:: output_14_22.png



.. image:: output_14_23.png



.. image:: output_14_24.png



.. image:: output_14_25.png



.. image:: output_14_26.png



.. image:: output_14_27.png



.. image:: output_14_28.png



.. image:: output_14_29.png



.. image:: output_14_30.png



.. image:: output_14_31.png



.. image:: output_14_32.png



.. image:: output_14_33.png



.. image:: output_14_34.png



.. image:: output_14_35.png



.. image:: output_14_36.png



.. image:: output_14_37.png



.. image:: output_14_38.png



.. image:: output_14_39.png


.. code:: ipython3

    # Merge Clean and Malicious Grover Datasets
    
    import pandas as pd
    
    # Load both datasets
    clean_df = pd.read_csv("grover_clean_dataset.csv")
    malicious_df = pd.read_csv("grover_malicious_dataset.csv")
    
    # Combine into a single DataFrame
    combined_df = pd.concat([clean_df, malicious_df], ignore_index=True)
    
    # Save the combined dataset
    combined_df.to_csv("grover_full_dataset.csv", index=False)
    
    # Display the final dataset shape and preview
    pd.set_option('display.max_columns', None)
    
    # Show a preview of the combined dataset again
    combined_df.head(10)
    
    
    




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>depth</th>
          <th>cx</th>
          <th>h</th>
          <th>x</th>
          <th>ccx</th>
          <th>total_gates</th>
          <th>success_rate</th>
          <th>entropy</th>
          <th>unique_states</th>
          <th>label</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>grover_clean_0</td>
          <td>12</td>
          <td>0</td>
          <td>11</td>
          <td>12</td>
          <td>2</td>
          <td>29</td>
          <td>16.650391</td>
          <td>2.923333</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>grover_clean_1</td>
          <td>11</td>
          <td>0</td>
          <td>11</td>
          <td>10</td>
          <td>2</td>
          <td>27</td>
          <td>18.359375</td>
          <td>2.932354</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>grover_clean_2</td>
          <td>12</td>
          <td>0</td>
          <td>11</td>
          <td>10</td>
          <td>2</td>
          <td>27</td>
          <td>16.113281</td>
          <td>2.985350</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>grover_clean_3</td>
          <td>11</td>
          <td>0</td>
          <td>11</td>
          <td>8</td>
          <td>2</td>
          <td>25</td>
          <td>18.945312</td>
          <td>2.940776</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>grover_clean_4</td>
          <td>12</td>
          <td>0</td>
          <td>11</td>
          <td>10</td>
          <td>2</td>
          <td>27</td>
          <td>18.945312</td>
          <td>2.937411</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>5</th>
          <td>grover_clean_5</td>
          <td>11</td>
          <td>0</td>
          <td>11</td>
          <td>8</td>
          <td>2</td>
          <td>25</td>
          <td>18.188477</td>
          <td>2.951969</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>6</th>
          <td>grover_clean_6</td>
          <td>12</td>
          <td>0</td>
          <td>11</td>
          <td>8</td>
          <td>2</td>
          <td>25</td>
          <td>21.728516</td>
          <td>2.918748</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>7</th>
          <td>grover_clean_7</td>
          <td>10</td>
          <td>0</td>
          <td>11</td>
          <td>6</td>
          <td>2</td>
          <td>23</td>
          <td>17.456055</td>
          <td>2.973883</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>8</th>
          <td>grover_clean_8</td>
          <td>10</td>
          <td>0</td>
          <td>11</td>
          <td>6</td>
          <td>1</td>
          <td>23</td>
          <td>52.563477</td>
          <td>1.619115</td>
          <td>8</td>
          <td>0</td>
        </tr>
        <tr>
          <th>9</th>
          <td>grover_clean_9</td>
          <td>10</td>
          <td>0</td>
          <td>11</td>
          <td>6</td>
          <td>1</td>
          <td>23</td>
          <td>45.288086</td>
          <td>1.684894</td>
          <td>8</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    ### Dataset Exploration: Class Balance and Feature Correlation
    # 
    # Before proceeding to model training, it is important to understand the structure and distribution of the dataset. This step includes:
    # 
    # 1. **Class Balance Visualization**  
    # We visualize the distribution of class labels (Clean = 0, Malicious = 1) to ensure that the dataset is not imbalanced. A balanced dataset helps in avoiding biased models that favor the majority class.
    # 
    # 2. **Feature Correlation Heatmap**  
    # A heatmap of feature-to-feature correlation is plotted to identify redundant or highly correlated attributes. This helps in:
    #  - Understanding which features carry similar information.
    #  - Deciding whether feature reduction or dimensionality techniques are needed.
    #  - Revealing potential multicollinearity before model training.
    #
    # These plots offer insights into dataset quality and are critical for data-driven model design decisions.
    

.. code:: ipython3

    import matplotlib.pyplot as plt
    import seaborn as sns
    import os
    
    # Create folder to save plots
    os.makedirs("analysis_plots", exist_ok=True)
    
    # ---------- CLASS BALANCE ----------
    label_counts = combined_df['label'].value_counts().sort_index()
    label_df = pd.DataFrame({
        'Label': ['Clean', 'Malicious'],
        'Count': label_counts.values
    })
    
    # Plot Class Balance
    plt.figure(figsize=(6, 4))
    sns.barplot(x='Label', y='Count', data=label_df, palette='Set2')
    plt.title("Class Balance: Clean (0) vs Malicious (1)")
    plt.xlabel("Class Label")
    plt.ylabel("Number of Samples")
    plt.tight_layout()
    plt.savefig("analysis_plots/class_balance.png")
    plt.show()
    
    # ---------- CORRELATION HEATMAP ----------
    plt.figure(figsize=(10, 8))
    correlation = combined_df.corr(numeric_only=True)
    sns.heatmap(correlation, annot=True, fmt=".2f", cmap="coolwarm", linewidths=0.5)
    plt.title("Feature Correlation Heatmap")
    plt.tight_layout()
    plt.savefig("analysis_plots/feature_correlation_heatmap.png")
    plt.show()
    


.. parsed-literal::

    C:\Users\zeesh\AppData\Local\Temp\ipykernel_14432\3893632335.py:17: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x='Label', y='Count', data=label_df, palette='Set2')
    


.. image:: output_17_1.png



.. image:: output_17_2.png


